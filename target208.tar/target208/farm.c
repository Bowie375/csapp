/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_318(unsigned *p)
{
    *p = 3347663034U;
}

void setval_256(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_309()
{
    return 3351742792U;
}

unsigned addval_328(unsigned x)
{
    return x + 2425394264U;
}

unsigned addval_363(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_311()
{
    return 3351742792U;
}

unsigned addval_433(unsigned x)
{
    return x + 2438469858U;
}

void setval_466(unsigned *p)
{
    *p = 2425378889U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_347()
{
    return 3100104329U;
}

unsigned addval_139(unsigned x)
{
    return x + 3281308297U;
}

unsigned getval_475()
{
    return 3767097518U;
}

void setval_408(unsigned *p)
{
    *p = 3531918025U;
}

void setval_272(unsigned *p)
{
    *p = 3224945049U;
}

void setval_182(unsigned *p)
{
    *p = 2464188744U;
}

void setval_462(unsigned *p)
{
    *p = 3229928137U;
}

unsigned addval_228(unsigned x)
{
    return x + 3525367433U;
}

void setval_314(unsigned *p)
{
    *p = 3526937224U;
}

void setval_247(unsigned *p)
{
    *p = 3682124169U;
}

unsigned addval_263(unsigned x)
{
    return x + 3375945417U;
}

void setval_442(unsigned *p)
{
    *p = 3674786441U;
}

void setval_492(unsigned *p)
{
    *p = 3525364361U;
}

unsigned addval_208(unsigned x)
{
    return x + 3675832713U;
}

void setval_161(unsigned *p)
{
    *p = 3374367113U;
}

unsigned addval_360(unsigned x)
{
    return x + 3680551305U;
}

unsigned getval_248()
{
    return 3286272320U;
}

unsigned getval_119()
{
    return 3677935233U;
}

void setval_186(unsigned *p)
{
    *p = 2425673353U;
}

unsigned getval_219()
{
    return 3269495112U;
}

unsigned addval_184(unsigned x)
{
    return x + 3222850185U;
}

unsigned getval_209()
{
    return 1103222409U;
}

unsigned getval_109()
{
    return 3229931145U;
}

void setval_329(unsigned *p)
{
    *p = 3224945033U;
}

unsigned addval_265(unsigned x)
{
    return x + 3286270280U;
}

unsigned getval_405()
{
    return 2430634312U;
}

unsigned getval_130()
{
    return 3676881289U;
}

unsigned addval_401(unsigned x)
{
    return x + 2430650696U;
}

void setval_400(unsigned *p)
{
    *p = 3223374505U;
}

unsigned getval_193()
{
    return 3372275337U;
}

unsigned getval_274()
{
    return 3767093440U;
}

unsigned getval_452()
{
    return 3674784141U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
