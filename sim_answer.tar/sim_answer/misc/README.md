
## Y86-64 Assembler, Instruction Simulator, and HCL ranslator

##### Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.<br/;>May not be used, modified, or copied without permission.

---

This directory contains all of the source files for the following:

* YAS   $~~~~~~~~$  -- Y86-64 assembler
* YIS   $~~~~~~~~~~$--Y86-64 instruction level simulator
* HCL2C	$~~~~$--HCL to C translator
* HCL2V	$~~~~$--HCL to Verilog translator
> Note:
> * YAS is the compiler for assembly code writen in y86 format, just like gcc. you can use it by typing :
`$ ./yas sum.ys`
>    then you get `sum.yo` as it's output file.
> * YIS is used to simulate running your .yo  file on a real computer. The basic idea is quite intuitive: use different variable to play the rule of the registers, the memory, and so on. Usage:
> `$ ./yis sum.yo`
> then you get the informationn of how your register changed, how your memory changed and how much cycle did you use for running this program.
> * You don't need to care too much about the other two files, they didn't provide you with a .c file to figure that out too. These files are used to compile your .hcl file, you can use `objdump` to know more about it.  
 
## 1. Building the tools
*********************

>`unix> make clean`
>`unix> make`

You need these files to carry on latter work.
## 2. Files
---
* Makefile		Builds yas, yis, hcl2c, hcl2v
* README			This file <br/><br/>
* Versions of Makefile in the student's distribution
* Makefile-sim (Instructor distribution only)<br/><br/>
* Example programs for Part A of the CS:APP Architecture Lab
    * examples.c:	 $~~~~~~~$	C versions of three Y86-64 functions 
    * ans-bubble.ys:	 $~~~$	Solution bubble function (instructor distribution only)
    * ans-sum.ys:	$~~~~~~~$	Solution sum function (instructor distribution only)
    * ans-rsum.ys:	$~~~~~~$	Solution rsum function (instructor distribution only)


* Instruction simulator code shared by yas, yis, ssim, ssim+, and psim
    * isa.c $~~~~~~~~~~~~~~~~$<mark>--You can find the byte level definition of each instruction in this file.</mark>
    * isa.h

* Files used to build the yas assembler
    * yas:	$~~~~~~~~~~~~~~~~~~~~~~$		The YAS binary
    * yas.c:	$~~~~~~~~~~~~~~~~~~~~$		yas source file and header file
    * yas.h:
    * yas-grammar.lex:	$~~~$	Y86-64 lexical scanner spec
    * yas-grammar.c:	$~~~~~~$	Lexical scanner generated from    yas-grammar.lex

* Files used to build the yis instruction simulator
    * yis:	$~~~~~~~~~~~~~~~~~$		The YIS binary
    * yis.c:	$~~~~~~~~~~~~~~~$		yis source file $~~$<mark>The program level abstraction of SEQ </mark>

* Files used to build the hcl2c translator
    * hcl2c:	$~~~~~~~~~~~~~~$		The HCL2C binary
    * node.c:	$~~~~~~~~~~~~$		auxiliary routines and header file
    * node.h:
    * hcl.lex:	$~~~~~~~~~~~~~$		HCL lexical scanner spec
    * lex.yy.c:	$~~~~~~~~~~~$	HCL lexical scanner generated from hcl.lex
    * hcl.y:	 $~~~~~~~~~~~~~~~$		HCL grammar
    * hcl.tab.c: $~~~~~~~~~~$		HCL parser generated from hcl.y
    * hcl.tab.h:$~~~~~~~~~~$		Token definitions

* Example HCL programs used during the writing of the CS:APP book
* (Instructor distribution only)
    * frag.{hcl,c}
    * mux4.{hcl,c}
    * reg-file.{hcl,c}

## some word to say
This part of lab is designed to get you accustomed to Y86 format of assembly code. It's just a piece of cake for you.
If you need, you may use gcc to compile the example.c file to get the X86 format of assembly code, and simply translate it to Y86 to get the right answer.

