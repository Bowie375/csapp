#####################################################################
# Autolab Version of the CS:APP Proxy Lab
# Driver source files
#
# Copyright (c) 2004, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
# Modified by Wang Zizhou in PKU, 2018-12
# To add the support for IO-Multiplexing method.
######################################################################

***********
1. Overview
***********

This folder contains my answers for this lab. 

The fourth part is left undone, the first three parts (compulsory ones) 
can run smoothly. 

To give a high level description of my answer, I used

    * threads
    * semaphore
    * cache based on doubly linked list

to finish this lab.

**********************************
2. Modified or newly created Files
**********************************

You may modify these files as you like

* Makefile
    - ./Makefile : modified to implement following functions
        1. compile and link cache.c
        2. automatically run ./proxy and  ./tiny/tiny on designated ports
        3. create and remove log files used for debugging

    - ./tiny/Makefile : modified to implement following functions
        1. create and remove log files used for debugging
        
* cache.c & cache.h
    used for implement the third part for this lab. 
    
* proxy.c
    main workspace

* ./tiny/tiny.c
    modified to reorient log messages to "tiny_output.txt"

* proxy_output.txt & cache_output.txt & tiny/tiny_output.txt
    files to store log messages. You will see them after typing command "make"


****************
3. Tricky Points
****************

These are what I have struggled through while debugging,
and I wish you won't be stumbled be these :

* __Use strlen, strcpy and strcat carefully__ , 
    try to use memcpy and memmov instead, as some files are absolutely not
    comprised of ASCIIs . 

* __Think for a while about how to Use semaphores__
    If you simply lock everthing, a test case using 'nop-server' will perplex you.
    You may check nop-server.py to find why.
    this server cheats you to believe it will write to the socket by accept your connection, 
    however it actually dose nothing but spinning around. 
    So you won't be able to receive anything for the following requests if you 
    set up the lock at the beginning.

* __Mind your ways of reading from client and server__ 
    These two reading process are not the same. To show such an aspect, I would say 
    you actually have different ways to determine when to stop reading.