#ifndef __USE_POSIX
#define __USE_POSIX
#endif
#include "csapp.h"
#include "cache.h"

#define DEBUGx
#define USECACHE

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

static void doit(int connfd);
static int parse_url(char *url, char *hostname, char *port, char *uri);
static int transfer_to_server(int proxyfd, rio_t *rio);
static void read_response(rio_t *rio, int connfd, char *filename);
static void transfer_to_client(int connfd, char *response_buf, int blksize);
static void* thread(void *args);
static void sigstop_handler();
static void init_lock(void);

static int readcnt = 0; // reader number, initially 0
static sem_t mutex, w;  // initially 1

int main(int argc, char** argv)
{
#ifdef DEBUG
    FILE *outfile = fopen("proxy_output.txt", "w");
    Dup2(fileno(outfile), STDOUT_FILENO);

    fprintf(outfile, "proxy in on ...\n");
    fflush(outfile);
#endif

    signal(SIGPIPE, SIG_IGN);
    signal(SIGTERM, sigstop_handler);
    signal(SIGTSTP, sigstop_handler);
    signal(SIGINT, sigstop_handler);

    int listenfd, *pconnfd;
#ifdef DEBUG
    char hostname[MAXLINE], port[MAXLINE];
#endif
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    pthread_t tid;

    /* Check command line args */
    if(argc != 2){
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    init_lock();
#ifdef USECACHE
    init_cache();
#endif

    listenfd = open_listenfd(argv[1]);

    while(1){
        pconnfd = malloc(sizeof(int));

        clientlen = sizeof(clientaddr);
        *pconnfd = accept(listenfd, (SA*)&clientaddr, &clientlen);
        
#ifdef DEBUG
        /* print client info */
        Getnameinfo((SA *)&clientaddr, clientlen, hostname, MAXLINE,\
                    port, MAXLINE, 0);
        fprintf(outfile, "Accepted connection from (%s, %s)\n", hostname,port);
        fflush(outfile);
#endif

        Pthread_create(&tid, NULL, &thread, pconnfd);
    }

#ifdef DEBUG
    fclose(outfile);
#endif

#ifdef USECACHE
    delete_cache();
#endif

    return 0;
}


/*************************************************
 * The following routine is the main work of proxy
 ************************************************/

void doit(int connfd){
    int retval = 0;
    int proxyfd = 0;
    char buf[MAXLINE];
    char method[MAXLINE], url[MAXLINE], version[MAXLINE];
    char hostname[MAXLINE],port[MAXLINE], uri[MAXLINE];
#ifdef USECACHE
    char response_buf[MAX_OBJECT_SIZE];
#endif
    rio_t rio_client, rio_server;

    /* read request line and headers */
    rio_readinitb(&rio_client, connfd);
    if (!rio_readlineb(&rio_client, buf, MAXLINE)){
        return;
    }

    /* request too long */
    if(!strstr(buf, "\r\n")){
        return;
    }

#ifdef DEBUG
    fprintf(stdout, "%s", buf);
    fflush(stdout);
#endif

    retval = sscanf(buf, "%s %s %s",method, url, version);
    
    /* request in bad format */
    if(retval <=0 ){
        return;
    }

    /* Parse URI from GET request */
    retval = parse_url(url, hostname, port, uri);

    if(retval < 0){ // illegal url
        return;        
    }

#ifdef USECACHE
    P(&mutex);
    retval = retrieve_from_cache(response_buf, uri);
    V(&mutex);
    /* try to get the response from cache */
    if(retval >= 0){
        transfer_to_client(connfd, response_buf, retval);
        return;
    }
#endif

    /* transfer to  */
    proxyfd = open_clientfd(hostname, port);

    /* fail to open clientfd */
    if(proxyfd < 0 ){

#ifdef DEBUG
    fprintf(stderr, "error: proxy failed to connect to server!\n");
#endif
        return;
    }

    rio_readinitb(&rio_server, proxyfd);

    sprintf(buf, "%s %s %s\n", method, uri, version);
    rio_writen(proxyfd, buf, strlen(buf));
    retval = transfer_to_server(proxyfd, &rio_client);

    if(retval < 0){ // illegal headers received
        return;
    }

    read_response(&rio_server, connfd, uri);

    close(proxyfd);
}


/***************************************************
 * The following routines are stages of proxy's work
 **************************************************/

/*
 * transfer_to_server - read client request headers and 
 *                      forward them to server.
 *
 * return value : return 0 if succeed or -1 if error occurs
 */
int transfer_to_server(int proxyfd, rio_t *rp){
    char buf[MAXLINE];
    char tmp_buf[MAXLINE];
    buf[0] = '\0', tmp_buf[0] = '\0';

    rio_readlineb(rp, tmp_buf, MAXLINE);
#ifdef DEBUG
    fprintf(stdout, "%s", tmp_buf);
    fflush(stdout);
#endif
    /* deal with header in bad format */
    if(!strstr(tmp_buf, "\r\n")){
        return -1;
    }

    if(strstr(tmp_buf, "User-Agent")){
        strcat(buf, user_agent_hdr);
    }
    else if(strstr(tmp_buf, "Connection")){
        strcat(buf,"Connection: close\r\n");
    }
    else if(strstr(tmp_buf, "Proxy-Connection"))
    {
        strcat(buf, "Proxy-Connection: close\r\n");
    }
    else{
        strcat(buf, tmp_buf);
    }

    while(strcmp(tmp_buf, "\r\n")){
#ifdef DEBUG
        fprintf(stdout, "%s", tmp_buf);
        fflush(stdout);
#endif
        rio_readlineb(rp, tmp_buf, MAXLINE);

        /* deal with header in bad format */
        if(!strstr(tmp_buf, "\r\n")){
            return -1;
        }

        /* designated headers */
        if(strstr(tmp_buf, "User-Agent")){
            strcat(buf, user_agent_hdr);
        }
        else if(strstr(tmp_buf, "Connection")){
            strcat(buf,"Connection: close\r\n");
        }
        else if(strstr(tmp_buf, "Proxy-Connection"))
        {
            strcat(buf, "Proxy-Connection: close\r\n");
        }
        else{
            strcat(buf, tmp_buf);
        }
    }    

    rio_writen(proxyfd, buf, strlen(buf));

    return 0;
}


/*
 * read_response - read server response
 */
void read_response(rio_t *rp, int connfd, char *filename){
    char buf[MAXLINE]; 
#ifdef USECACHE
    char response_buf[MAX_OBJECT_SIZE];
    int blksize = 0, discard = 0;
    int nread = 0;
    response_buf[0] = '\0';
#endif

    while((nread = rio_readlineb(rp, buf, MAXLINE))){
#ifdef DEBUG
        fprintf(stdout, "%s", buf);
        fflush(stdout);
#endif
        rio_writen(connfd, buf, nread);
#ifdef USECACHE
        /* determine if this block is too large to cache */
        if(!discard){
            if(blksize + nread >= MAX_OBJECT_SIZE){
                discard = 0;
                continue;
            }
            memmove((void*)(response_buf + blksize), (void*)buf, nread);
            blksize += nread;
        }
#endif
    }

#ifdef USECACHE
    /* put this block in cache */
    if(!discard){
        P(&w);
        cache_blk(filename, response_buf, blksize);
        V(&w);
    }
#endif
}

/*
 * transfer_to_client - forward server response back to client
 */
void transfer_to_client(int connfd, char *response_buf, int blksize){
    rio_writen(connfd, response_buf, blksize);
}


/*******************************************
 * The following routines are thread related
 ******************************************/

/*
 * thread - main work of threads
 */
void* thread(void *args){
    int *pconnfd = (int*) args;
    int connfd = *pconnfd;

    Pthread_detach(pthread_self());

    doit(connfd);

    free(pconnfd);
    close(connfd);
    return NULL;
}

/*
 * init_lock - initialize locks used in concurrent jobs
 */
void init_lock(void){
    Sem_init(&mutex, 0, 1);
    Sem_init(&w, 0, 1);
    readcnt = 0;
}

/*****************************************
 * The following routine manipulate string
 ****************************************/

/*
 * parse_url - parse url into different parts, and store them
 *             in given private array ptrs;
 *
 * return value : return 0 if succeed or -1 if error occurs
 */
int parse_url(char *url, char *hostname, char *port, char *uri){
    char *ptr, *tmp_ptr;

    ptr = strstr(url, "//");

    if(!ptr){ // url in bad format
        return -1;
    }

    *ptr = ' ', *(ptr+1) = ' ';
    tmp_ptr = ptr + 2;

    /* hostname : port */
    ptr = index(url, '/');

    if(!ptr){ // url in bad format
        return -1;
    }

    *ptr = '\0';
    strcpy(hostname, tmp_ptr);

    /* uri */
    strcpy(uri, "/");
    strcat(uri, ptr+1);

    /* contain port part */
    if((ptr = index(hostname, ':'))){
        *ptr = '\0';
        strcpy(port, ptr+1);
    }
    /* don't contain port */
    else{
        strcpy(port, "");
    }

    return 0;
}



/********************************************
 * The following routines are signal handlers
 *******************************************/

void sigstop_handler(){
    delete_cache();
    exit(0);
}