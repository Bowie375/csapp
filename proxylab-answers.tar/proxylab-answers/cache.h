#include "csapp.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

void init_cache(void);
void delete_cache(void);
int retrieve_from_cache(char *dest, char *filename);
void cache_blk(char *filename, char *block, int blksize);

