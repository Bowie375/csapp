#include "cache.h"

#define DEBUG_CACHEx

struct response{
    int blksize;
    char *filename;
    char *block;
    struct response *next;
    struct response *prev;
};

static void remov_blk(struct response *ptr);
static void evict(int blksize);
static struct response *in_cache(char *filename);

static int available_space;
static struct response *header_ptr;
static struct response *rear_ptr;

/*
 * init_cache - initialize static variables
 */
void 
init_cache(){
#ifdef DEBUG_CACHE
    FILE *outfile = fopen("cache_output.txt", "w");
    fprintf(outfile, "cache initialized...\n");
    fflush(outfile);
    fclose(outfile);
#endif

    header_ptr = malloc(sizeof(struct response));
    
    header_ptr->blksize = 0;
    header_ptr->filename = NULL;
    header_ptr->block = NULL;
    header_ptr->next = NULL;
    header_ptr->prev = NULL;

    rear_ptr = header_ptr;

    available_space = MAX_CACHE_SIZE;
}

/*
 * delete_cache - free memory dynamicaly allocated for cache
 */
void 
delete_cache(){
    struct response *nowptr=NULL, *tmpptr=NULL;

    nowptr = header_ptr;

    if(!nowptr){
        return;
    }

    while(nowptr->next){
        tmpptr = nowptr->next;
        free(nowptr->block);
        free(nowptr->filename);
        free(nowptr);
        nowptr = tmpptr;
    }

    free(nowptr->block);
    free(nowptr->filename);
    free(nowptr);
    header_ptr = NULL;
    rear_ptr = NULL;

#ifdef DEBUG_CACHE
    FILE *outfile = fopen("cache_output.txt", "a");
    fprintf(outfile, "cache deleted successfully\n");
    fflush(outfile);
    fclose(outfile);
#endif
}

/*
 * retrieve_from _cache - try to find and retrieve a response
 *                      in cache.
 *  
 * return value:
 *      - -1 if did't find the response in cache;
 *      - size of the block if found, then *dest is filled with the content. 
 * 
 */
int
retrieve_from_cache(char *dest, char *filename){
    struct response *ptr = in_cache(filename), *preptr = NULL;

    if(!ptr){
        return -1;
    }
    else{
        memcpy((void*)dest, (void*)ptr->block, ptr->blksize);
        /* implement LRU method: 
         *   put recently visited block at the front of list
         */
        preptr = ptr->prev;
        preptr->next = ptr->next;
        if(ptr->next){
            ptr->next->prev = preptr;
        }

        ptr->next = header_ptr->next;
        ptr->prev = header_ptr;
        if(header_ptr->next){
            header_ptr->next->prev = ptr;
        }
        header_ptr->next = ptr;

#ifdef DEBUG_CACHE
    FILE *outfile = fopen("cache_output.txt", "a");
    fprintf(outfile, "cache hit!\n");
    fflush(outfile);
    fclose(outfile);
#endif

        return ptr->blksize;
    }
}

/*
 * cache_blk - put a block in cache 
 */
void 
cache_blk(char *filename, char *block, int blksize){
    struct response *new_respns;
    
    if(in_cache(filename)){
        return;
    }

    if(blksize > MAX_OBJECT_SIZE){
        return;
    }

    new_respns = malloc(sizeof(struct response));
    /* +2 to avoid overflow */
    new_respns->filename = malloc(strlen(filename)+2);
    new_respns->block = malloc(blksize);

    new_respns->blksize = blksize;
    strcpy(new_respns->filename, filename);
    memcpy((void*)new_respns->block, (void*)block, blksize);

    /* need eviction */
    if(available_space <= blksize){
        evict(blksize);
    }

    /* add to front */    
    new_respns->next = header_ptr->next;
    new_respns->prev = header_ptr;
    if(header_ptr->next){
        header_ptr->next->prev = new_respns;
    }else{ // empty cache
        rear_ptr = new_respns;
    }
    header_ptr->next = new_respns;

    available_space -= blksize;

#ifdef DEBUG_CACHE
    FILE *outfile = fopen("cache_output.txt", "a");
    fprintf(outfile, "I added a block to cache! available_space: %d\n", available_space);
    fflush(outfile);
    fclose(outfile);
#endif
}


/****************************************************
 * The following routines are static helper functions
 ***************************************************/

/*
 * remov_blk - remove certain block from list
 */
void 
remov_blk(struct response *ptr){
    /* ignore empty ptr and header ptr */
    if(!ptr){
        return;
    }
    if(ptr == header_ptr){
        return;
    }

    available_space += ptr->blksize;

    ptr->prev->next = ptr->next;
    if(ptr->next){
        ptr->next->prev = ptr->prev;
    }
    free(ptr->filename);
    free(ptr->block);
    free(ptr);
#ifdef DEBUG_CACHE
    FILE *outfile = fopen("cache_output.txt", "a");
    fprintf(outfile, "I removed a block.\n");
    fflush(outfile);
    fclose(outfile);
#endif
}

/*
 * evict - evict blocks until enough room is found
 *
 * note : LRU strategy is used
 */
void 
evict(int blksize){
    while(rear_ptr != header_ptr){
        rear_ptr = rear_ptr->prev;
        remov_blk(rear_ptr->next);

        if(available_space > blksize){
            break;
        }
    }
#ifdef DEBUG_CACHE
    FILE *outfile = fopen("cache_output.txt", "a");
    fprintf(outfile, "I finished an eviction\n");
    fflush(outfile);
    fclose(outfile);
#endif

}

/*
 * in_cache - check is certain file exist in cached list
 *
 * return value:
 *      - NULL if don't exist
 *      - ptr to the response struct if exist
 */
struct response*
in_cache(char *filename){
    struct response *ptr = NULL;

    /* nothing cached now */
    if(!(header_ptr->next)){
        return NULL;
    }

    ptr = header_ptr->next;
    while(ptr){
        if(strcmp(filename, ptr->filename) == 0){
            return ptr;
        }

        ptr = ptr->next;
    }

#ifdef DEBUG_CACHE
    FILE *outfile = fopen("cache_output.txt", "a");
    fprintf(outfile, "didn't find a matching block\n");
    fflush(outfile);
    fclose(outfile);
#endif

    return NULL;
}